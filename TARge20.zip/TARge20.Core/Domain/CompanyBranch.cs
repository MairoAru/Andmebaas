﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TARge20.Core.Domain
{
    public class CompanyBranch
    {
        [Key]
        public Guid Id { get; set; }
        [ForeignKey("CompanyID")]
        public virtual Company Company { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string ContactPerson { get; set; }
        public int PhoneNr { get; set; }
        public string Email { get; set; }
        public string Comment { get; set; }

        public ICollection<LoandItems> LoandItems { get; set; }


    }
}
