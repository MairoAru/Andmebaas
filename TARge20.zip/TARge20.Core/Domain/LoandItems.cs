﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TARge20.Core.Domain
{
     public class LoandItems
    {
        [Key]
        public Guid Id { get; set; }
        [ForeignKey("CompanyID")]
        public virtual Company Company { get; set; }
        [ForeignKey("EmployeeID")]
        public virtual Employee Employee { get; set; }
        public string LoandItem { get; set; }
        public string Description { get; set; }
        public int Amount { get; set; }
        public DateTime LoanStart { get; set; }
        public DateTime LoanEnd { get; set; }
        public string Comment { get; set; }
    }
}
