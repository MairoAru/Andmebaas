﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace TARge20.Core.Domain
{
    [Table("Employee")]
    public partial class Employee
    {
        [Key]
        public Guid Id { get; set; }
        [ForeignKey("CompanyID")]
        public virtual Company Company { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string IDCode { get; set; }
        public string Address { get; set; }
        public int PhoneNr { get; set; }
        public string Email { get; set; }
        public DateTime StartDate { get; set; }
        public string WorkTill { get; set; }
        public string Comment { get; set; }

        public ICollection<Children> Childrens { get; set; }
        public Accsess Accsesses { get; set; }
        public HealthCheck HealthCheck { get; set; }
        public ICollection<SickLeaves> SickLeaves { get; set; }
        public WorkTitle WorkTitle { get; set; }
        public ICollection<Vacations> Vacations { get; set; }
        public ICollection<LoandItems> LoandItems { get; set; }

    }   

}
